
<?php $title =null; ?>
<!-- content -->
<div class="app-content content">
      <!-- right content -->
      <div class="sidebar-right sidebar-sticky">
        <div class="sidebar">
         <div class="pt-2 pr-2">
          <div class="sidebar-content p-1" data-spy="affix" data-offset-top="-77">
           <div class="card">
            <div class="card-header">
                <h6 class="card-title"><?php echo e($title); ?></h6>
            </div>
            <div class="card-content" aria-expanded="true">
                <div class="card-body">
                    <nav id="sidebar-page-navigation">
                        <ul id="page-navigation-list" class="nav">
                           
                          <?php if(!Route::has('dashboard')): ?>
                            <li class="nav-item"><a class="btn btn-primary" href="<?php echo e(route(request()->segment(2).'.create')); ?>"><?php echo e(__('main.create')." ".__('main.'.request()->segment(2))); ?></a></li>
                          <?php endif; ?> 
                            <li class="nav-item"><a class="btn btn-defualt" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('main.home')); ?></a></li>
                        </ul>
                    </nav>
                </div>
                
            </div>
           </div>
          </div>
         </div>

        </div>
      </div>
      <!--end right content -->

      <!--left content -->
      <div class="content-left">
        <div class="content-wrapper">
          <!-- header title -->
          <div class="content-header row">
            
            <div class="content-header-left col-md-6 col-12 mb-1">
              <h2 class="content-header-title"><?php echo e($title); ?></h2>
            </div>
            
            <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item <?php echo e(Route::currentRouteName() ? 'active' : ''); ?>"><a href="#"><?php echo e(__('main.home')); ?></a>
                  </li>
                  <li class="breadcrumb-item <?php echo e(Route::currentRouteName() ? 'active' : ''); ?>"><a href="#"><?php echo e(__('main.'.request()->segment(2))); ?></a>
                  </li>
                  
                </ol>
              </div>
            </div>
          
          </div>
         <!--end header title -->

         <!-- header content-->
          <div class="content-body">
            <section id="columns-2">
              <!-- CSS Classes -->
              <section id="columns-2-css" class="card">
                  <div class="card-header">
                      <h4 class="card-title"><?php echo $__env->yieldContent('title'); ?></h4>
                  </div>
                  <div class="card-content" aria-expanded="true">
                      <div class="card-body">
                          <div class="card-text">
                              <?php echo $__env->yieldContent('content'); ?>
                             
                          </div>
                      </div>
                  </div>
              </section>
              <!--/ CSS Classes -->
            </section>
          </div>
         <!--end header content-->
        </div>
      </div>
      <!-- end left content-->
    </div>
<!-- end content -->
<?php /**PATH C:\xampp\htdocs\test\resources\views/Dashboard/layouts/content.blade.php ENDPATH**/ ?>