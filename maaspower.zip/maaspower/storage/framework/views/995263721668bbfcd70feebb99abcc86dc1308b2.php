
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table table-hover">

    <thead>
            <tr>
                <th><?php echo e(__('main.name')); ?></th>
                <th><?php echo e(__('main.permissions')); ?></th>
                <th><?php echo e(__('main.actions')); ?></th>

            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($permission->slug); ?></td>
            <td>
                
                <a href="<?php echo e(route('permission.delete',$user->id)); ?>"  class="btn btn-danger"><?php echo e(trans('main.delete')); ?></a>
            </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/Dashboard/Users/Per_user.blade.php ENDPATH**/ ?>