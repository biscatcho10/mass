
<?php
    $languages = ['en','ar'];
    $locale = session()->get('locale');
?>

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-textdirection="<?php echo e(App::isLocale('ar') ? 'rtl': 'ltr'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <?php if(App::isLocale('en')): ?>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php else: ?>
    <link href="<?php echo e(asset('css/app-rtl.css')); ?>" rel="stylesheet">
    <?php endif; ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(__('main.'.config('app.name', 'Laravel') )); ?>

                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">
                      <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lang != $locale): ?>
                        <li class="nav-item">
                            <a class="btn btn-default btn-doc-header" href="<?php echo e(url('lang',$lang)); ?>" >
                            <img style="width: 30px;margin: 0px 3px;border-radius: 38%;" 
                                src="<?php echo e(asset($lang == 'ar' ? 'app-assets/images/flags/egypt.svg' : 'app-assets/images/flags/united-states.svg')); ?>">
                                <?php echo e($lang); ?>

                            </a>
                        </li>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('login/admin')); ?>"><?php echo e(__('main.login_admin')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('login/user')); ?>"><?php echo e(__('main.login_user')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('register/new/user')); ?>"><?php echo e(__('main.register')); ?></a>
                                </li>
                            <?php endif; ?>
                            
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                    
                                    <?php if(auth('admin')->check()): ?>
                                    <a href="<?php echo e(route('logout','admin')); ?>">
                                        <?php echo e(__('main.logout')); ?>

                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('logout','web')); ?>">
                                        <?php echo e(__('main.logout')); ?>

                                    </a>
                                    
                                    <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\test\resources\views/layouts/app.blade.php ENDPATH**/ ?>