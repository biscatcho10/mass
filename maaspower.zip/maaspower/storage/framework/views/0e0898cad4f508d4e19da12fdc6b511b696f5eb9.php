


<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->guest()): ?>
  visitor
<?php else: ?>
  <?php if(auth()->user()->is_admin == 1): ?>
   <p> <?php echo e(__('messages.admin')); ?></p>
  <?php else: ?>
  <p> <?php echo e(__('messages.user')); ?></p>  
  <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/Dashboard/dashboard.blade.php ENDPATH**/ ?>