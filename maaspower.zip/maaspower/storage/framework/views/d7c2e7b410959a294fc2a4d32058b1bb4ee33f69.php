  
  <!-- Sidbar -->
  <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="main-menu-content menu-accordion">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
          
        <li class=" nav-item"><a href="#"><i class="ft-home"></i><span class="menu-title" data-i18n=""><?php echo e(__('main.'.config('app.name'))); ?></span></a>
        </li>

        <!-- users -->
          <li class=" nav-item"><a href="#"><i class="ft-settings"></i><span class="menu-title" data-i18n=""><?php echo e(__('main.users')); ?></span></a>
            <ul class="menu-content">
              
              <li><a class="menu-item" href="<?php echo e(route('users.index')); ?>"><?php echo e(__('main.users')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(route('add_per_user')); ?>"><?php echo e(__('main.create_permission_users')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(route('peruser')); ?>"><?php echo e(__('main.permission_users')); ?></a></li>
             
              <li><a class="menu-item" href="<?php echo e(route('users.create')); ?>"><?php echo e(__('main.create') ." ". __('main.users')); ?></a></li>
              
              
              
            </ul>
          </li>
        <!-- end users -->

        <!-- Roles & Permissions -->
        <li class=" nav-item"><a href="#"><i class="ft-settings"></i><span class="menu-title" data-i18n=""><?php echo e(__('main.roles')); ?></span></a>
          <ul class="menu-content">
            <li><a class="menu-item" href="<?php echo e(route('roles.index')); ?>"><?php echo e(__('main.roles')); ?></a></li>
            <li><a class="menu-item" href="<?php echo e(route('roles.create')); ?>"><?php echo e(__('main.create')." ". __('main.roles')); ?></a></li>
          </ul>
        </li>
        <li class=" nav-item"><a href="#"><i class="ft-settings"></i><span class="menu-title" data-i18n=""><?php echo e(__('main.permissions')); ?></span></a>    
          <ul class="menu-content">
               
            <li><a class="menu-item" href="<?php echo e(route('permissions.index')); ?>"><?php echo e(__('main.permissions')); ?></a></li>
            
            <li><a class="menu-item" href="<?php echo e(route('permissions.create')); ?>"><?php echo e(__('main.create')." ". __('main.permissions')); ?></a></li>
          
          </ul>
          </li>
        <!-- end Roles & Permissions -->
                
        </ul>
      </div>
    </div>
<!-- end sidbar -->
<?php /**PATH C:\xampp\htdocs\test\resources\views/Dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>