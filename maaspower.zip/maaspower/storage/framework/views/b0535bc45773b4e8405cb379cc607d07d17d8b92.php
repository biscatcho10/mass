
<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table table-hover">

        <thead>
            <tr>
                <th><?php echo e(__('main.name')); ?></th>
                <th><?php echo e(__('main.email')); ?></th>
                <th><?php echo e(__('main.mobile')); ?></th>
                <th><?php echo e(__('main.image')); ?></th>
                <th><?php echo e(__('main.actions')); ?></th>

            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = App\Models\User::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->mobile); ?></td>
            <td><img src="<?php echo e(asset($user->avatar)); ?>" class="brand-logo"></td>
            <td>
            <td>
                <a class="btn btn-info btn-sm" href="<?php echo e(route('users.edit',encrypt($user->id))); ?>"
                    title="<?php echo e(trans('main.edit')); ?>"><?php echo e(trans('main.edit')); ?><i class="fa fa-edit"></i></a>

                <a class="btn btn-info btn-sm" href="<?php echo e(route('users.show',encrypt($user->id))); ?>"
                    title="<?php echo e(trans('main.show')); ?>"><?php echo e(trans('main.show')); ?><i class="fa fa-eye"></i></a>

                <form action="<?php echo e(route('users.destroy','test')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('patch')); ?>

                  
                        <input type="hidden" name="id"  value="<?php echo e($user->id); ?>">
                        <button type="submit"class="btn btn-danger"><?php echo e(trans('main.delete')); ?></button>
                    
                </form>
            </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/Dashboard/Users/index.blade.php ENDPATH**/ ?>