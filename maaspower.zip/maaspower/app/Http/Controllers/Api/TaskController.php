<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Task;

class TaskController extends Controller
{
    public function store(Request $request)
    {
        try{
            //validation
            $validator = Validator::make($request->all(),[
                'title'=> 'required|string|max:255',
                'user_id' => 'required|numeric|exists:users,id', 
                'description' => 'required',
                'status'=> 'required|boolean', 
                'start_date' => 'required|date', 
                'end_date' => 'required|date',
                'start_time'=>'required', 
                'end_time' => 'required' 
            ]);
            if($validator->fails())
            {
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'error' => $validator->errors()
                ],401);
            }
            Task::create([
                'title'=> $request->title,
                'user_id' => $request->user_id, 
                'description' => $request->description,
                'status'=> $request->status, 
                'start_date' => $request->start_date, 
                'end_date' => $request->end_date,
                'start_time'=>$request->start_time, 
                'end_time' => $request->end_time 
            ]);
            return response()->json([
                'status' => true,
                'message' => 'Task Created'
            ],200);

        }catch(\Throwable $th)
        {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage(),
                
            ],500);
        }
    }
}
