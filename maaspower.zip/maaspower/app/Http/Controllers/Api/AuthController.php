<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    // public function __construct()
    // {
    //     return $this->middleware('auth:sanctum');
    // }
    
    public function register(Request $request)
    {
        try{
                //validation 
                $validateUser = Validator::make($request->all(),[
                    'name'=> 'required|string|max:255',
                    'mobile'=> 'required|numeric|unique:users,mobile',
                    'email'=> 'required|email|unique:users,email',
                    'password'=> 'required',
                ]);
             if($validateUser->fails())
             {
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors(),
                ],401);
             }
                //create
             $user  = User::create([
                'name'=> $request->name,
                'mobile'=> $request->mobile,
                'email'=> $request->email,
                'password'=> Hash::make($request->password),
             ]);
             return response()->json([
                'status' => true,
                'message' => 'User Create',
                'token' => $user->createToken('API TOKEN')->plainTextToken
            ],200);

        }catch(\Throwable $th)
        {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage(),
            ],500);
        }
    }

    public function login(Request $request)
    {
        try{
            //validation 
            $validateUser = Validator::make($request->all(),[
                'mobile'=> 'required|digits:9',
                'password'=> 'required',
            ]);
         if($validateUser->fails())
         {
            return response()->json([
                'status' => false,
                'message' => 'validation error',
                'errors' => $validateUser->errors()
                
            ],401);
         }

         if(!Auth::attempt($request->only(['mobile', 'password']))){
            return response()->json([
                'status' =>false,
                'message' => 'Mobile & Password Does Not Match With Our Record. '
            ],401);
         }

         $user = User::where('mobile' , $request->mobile)->first();

         return response()->json([
            'status' =>true,
            'message' => 'User Logged In Successfully' ,
            'token' => $user->createToken('API TOKEN')->plainTextToken
        ],200);

        }catch(\Throwable $th)
        {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage(),
                
            ],500);
        }
    }
}
