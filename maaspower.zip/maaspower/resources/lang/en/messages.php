<?php 

return [
    'logged' => 'You Are Logged Successfully!',
    'dashboard' => 'Dashboard',
    'admin' => 'Admin Are Logged Successfully!',
    'user' => 'User Are Logged Successfully!',
    'credentials_wrning' => 'Credentials are not allowed to login',
]

?>