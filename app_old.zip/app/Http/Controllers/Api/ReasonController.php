<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Models\ReasonForReject;
use App\Models\Task;
use App\Http\Controllers\Api\BaseController as BaseController;
use Illuminate\Support\Facades\Auth;
use Validator;

class ReasonController extends BaseController
{
    
    public function create(Request $request){
        try{
                
            $validator = Validator::make($request->all(), [
                'task_id' => 'required|exists:tasks,id',
                'description' => 'required',
            ]);    
            if($validator->fails()){
                return $this->sendError('Validation Error.', $validator->errors());       
            }
            $task = Task::find($request->task_id);
            
            if(Auth::user()->id == $task->assign_to){
               $input = $request->all();
                $input['user_id'] = Auth::user()->id;
                $data = ReasonForReject::create($input);
                
                $fcm_data = [
                    "to" =>$task->auther->fcm_token,
                    "notification" =>
                        [
                        "title" => 'reject task',
                        'body' => 'reject task from '.Auth::user()->name.'',
                        ],
                    "data" => [
                        "type" => 'Reject_by_user',
                        'title' => 'reject task',
                        'body' => 'reject task from '.Auth::user()->name.'',
                    ],
                ];
        
                send_notification_FCM($fcm_data);
                return $this->sendResponse($data, 'reason send successfully.'); 
            }
            return $this->sendError('Unauthorised.', ['error'=>'Unauthorised']);
            
        }catch(\Throwable $th){
            return response()->json([
                'status' => false,
                'message' => $th->getMessage(),
            ],500);
        }

    }
    

}
