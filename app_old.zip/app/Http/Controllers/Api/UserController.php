<?php
   
namespace App\Http\Controllers\Api;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\UserResource;
use App\Services\UserService;
use App\Http\Requests\UpdateUserRequest;

   
class UserController extends BaseController
{


    private $userService;

    /**
     * Create a new controller instance.
     *
     * @param  userService  $users
     * @return void
     */

    public function __construct(UserService $userService){
        $this->userService = $userService;
    }

    /**
     * Display a listing of the User combine transactions.
     *
     * @return JsonResponse
     */

    public function index()
    {
        $users = $this->userService->getAllUsers(); 
        return $this->sendResponse(UserResource::collection($users), 'Users list successfully.');
        
    }
    
    public function show($id){
        $user = $this->userService->getUser($id); 
        return $this->sendResponse(UserResource::make($user), 'User display  successfully.');
    }

    
   public function updateProfile(UpdateUserRequest $request){
        try {
            $user = Auth::user();
            $user->update( $request->all());
            
            return $this->sendResponse(UserResource::make($user), 'User updated successfully.');
         } catch (Exception $e) {
            return response()->json(['status' => 'false', 'message' => $e->getMessage(),'data'=>[]],500);
         }
        
    }
    
    public function showProfile(UpdateUserRequest $request){
        try {
            $user = Auth::user();
            
            return $this->sendResponse(UserResource::make($user), 'User show successfully.');
         } catch (Exception $e) {
            return response()->json(['status' => 'false', 'message' => $e->getMessage(),'data'=>[]],500);
         }
        
    }


     public function saveToken(Request $request)
    {
        $user = User::find($request->user_id);
        $user->fcm_token = $request->dev_token;
        $user->save();

        if($user)
            return response()->json([
                'message' => 'User token updated'
            ]);

        return response()->json([
            'message' => 'Error!'
        ]);
    }

}