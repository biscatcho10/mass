<?php
   
namespace App\Http\Controllers\Api;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;
use App\Models\Task;
use Illuminate\Support\Facades\Auth;
use Validator;
use App\Models\ReasonForReject;
use App\Models\Mark;
use App\Http\Resources\TaskResource;
use App\Http\Resources\ReasonResource;
use App\Services\TaskService;
use App\Http\Requests\TaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use DB;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class TaskController extends BaseController
{
   
    public function __construct(TaskService $taskService){
        $this->taskService = $taskService;
    }

    public function index(){    
        $tasks = $this->taskService->getAllTasks(); 
        
        $tasks = $tasks->map(function($task, $key) {
        	 $task->is_mark = $this->is_mark($task->id);
        	 return $task;
        });
        return $this->sendResponse(TaskResource::collection($tasks), 'tasks list successfully.');
    }
    
    public function show($id){
        $task = Task::findOrFail($id);
	    $task->is_mark = $this->is_mark($task->id);
        return $this->sendResponse(TaskResource::make($task), 'tasks list successfully.');
    }

    public function create(TaskRequest $request){
        $task = $this->taskService->createTask($request->all());
        $task->is_mark = FALSE;
        return $this->sendResponse(TaskResource::make($task), 'tasks craeted successfully.');
    
    }
    
    public function update(UpdateTaskRequest $request, $id){
        $task = $this->taskService->updateTask($request['status'],$id); 
        if($task){
            $task->is_mark = $this->is_mark($task->id);
            return $this->sendResponse(TaskResource::make($task), 'task updated successfully.'); 
        }
        return response()->json(['error' => 'Unauthenticated.'], 401);
    }
    
    
    public function destroy($id)
    {
        $task = Task::find($id);
        if($task){
            if($task->created_by == Auth::user()->id){
                $data =Task::destroy($id);
                Mark::where('task_id' , $id)->delete();
                return $this->sendResponse($data, 'task deleted successfully.');
            }
        }
        
        return $this->sendError('Unauthorised.', ['error'=>'Unauthorised']);
    
    }
    
    public function get_task_reason(){

        if(Auth::user()->hasRole('admin')){
            $data  =ReasonForReject::all();
            
        }else{
            
            $data =ReasonForReject::join('tasks', 'tasks.id', '=', 'reason_for_rejects.task_id')
            ->join('users', 'users.id', '=', 'tasks.created_by')
            ->where('tasks.created_by', '=', Auth::user()->id)
            ->get();
  
        }

        return $this->sendResponse(ReasonResource::collection($data)->resolve(), 'tasks reasons list successfully.');   
    }
    
    
    public function mark($id){
        try{
            $task = Task::findOrFail($id);
            if(in_array(Auth::user()->id , [$task->created_by,$task->assign_to])){
                $mark = Mark::firstOrCreate([ 'task_id' => $id]);
                $task = $mark->task;
                
                $task->is_mark = TRUE;
                
                return $this->sendResponse(TaskResource::make($task), 'tasks marked successfully.');
            }else{
                return response()->json(['error' => 'Unauthenticated.'], 401);
            }
        }
        catch(ModelNotFoundException $e){
            // dd(get_class_methods($e)); // lists all available methods for exception object
            return response()->json(['error' => 'Unauthenticated.'], 401);
        }

        
        
        
        
    }
    
    public function unmark($id){
         Mark::where('user_id',Auth::user()->id)->where('task_id',$id)->delete();
        $task = Task::find($id);
        $task->is_mark = FALSE;
        return $this->sendResponse(TaskResource::make($task), 'tasks unmarked successfully.');
        
    }
    
    
    public function filterTasks($status){
    
        switch($status){
            case('pending'):
                $tasks = Task::where('status',0)->get();
                break;
            case('approved'):
                $tasks = Task::where('status',1)->get();
                break;
            case('rejected'):
                $tasks = Task::where('status',2)->get();
                break;
            case('done'):
                $tasks = Task::where('status',3)->get();
                 break;
            case('expired'):
                $tasks = Task::where('status',4)->get();
                break;
            case('mark'):
               
                $tasks =  task::join('marks', 'marks.task_id', '=', 'tasks.id')->where('user_id',Auth::user()->id)->get(['tasks.*']);
                
                break;
            default:
                $tasks =Task::all();
        }
        
         $tasks = $tasks->map(function($task, $key) {
        	 $task->is_mark = $this->is_mark($task->id);
        	 return $task;
        });
                
        return $this->sendResponse(TaskResource::collection($tasks), 'tasks list successfully.');
        
                
        
    }
    
    protected function is_mark($id){
        return Mark::where('task_id' , $id)->where('user_id',Auth::user()->id)->exists();
    }
    

}