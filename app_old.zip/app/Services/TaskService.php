<?php

namespace App\Services;

use App\Repositories\TaskRepository;

class TaskService  
{
    protected $taskRepo;

    public function __construct (TaskRepository $taskRepo) {

        $this->taskRepo = $taskRepo;
    }


    public function getAllTasks(){
        
        return $this->taskRepo->getAllTasks();
    }


    public function createTask($request){
        
        return $this->taskRepo->createTask($request);
    }

    public function updateTask($request ,$id){
        
        return $this->taskRepo->updateTask($request , $id);
    }
   
}
 