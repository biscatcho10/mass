<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\ReasonForReject;
use Illuminate\Support\Facades\Auth;
use App\Interfaces\TaskRepositoryInterface;

class TaskRepository implements TaskRepositoryInterface 
{
 
    protected $task;

    public function __construct(Task $task ){
        $this->task = $task;
    }


    public function getAllTasks(){
        Task::where('end_date', '<',Carbon::now('Asia/Riyadh')->format('Y-m-d H:i:s'))->update(['status' =>'4']);
        if(Auth::user()->hasRole('admin')){ 
            $data = Task::all();    
        }else{
            $data = Task::where('assign_to',Auth::user()->id)->orWhere('created_by',Auth::user()->id)->get();
        }

        return $data;
        
    }

    public function createTask($data){
        
        if(isset($data['attachments'])){
            $files =[];
        
            foreach($data['attachments'] as $key=>$file){
                $files[] = $this->uploadFile($file);
            }
        
        
            $data['attachment'] = implode(",",$files);
        }
        
        if(isset($data['audio'])){
          
            $data['audio'] = $this->uploadFile($data['audio']);
        }
        
    
        $task = Task::create($data);
        $this->notifyUser($task->assign_to , $task->status ,'new task' ,'task from '.Auth::user()->name.'', $task->id);
        
        return $task;

    }

    public function updateTask($status ,$id){
        $task = Task::find($id);
        $status_var = ['pending','approved','rejected','done','expired'];
           
        if($task){
            if($task->created_by == Auth::user()->id ||Auth::user()->hasRole('admin')){
            
                $task = $this->update_status($task,(string)array_search ($status, $status_var));

                if($status == 'rejected'){
                    $this->reject_task($id);
                }
                
                $this->notifyUser($task->assign_to , $status ,'task is'.$status.'' ,'task from '.Auth::user()->name.'', $task->id);
                
                $this->delete_reason($id);

            }elseif($task->assign_to == Auth::user()->id && $status != 'rejected' ){

                $task = $this->update_status($task,(string)array_search ($status, $status_var));
                $this->notifyUser($task->created_by , $status ,'task is'.$status.'' ,'task from '.Auth::user()->name.'' , $task->id);
                $this->delete_reason($id);

            }else{
                return false;
            }

            return $task;
                        
        }
        return false;

    }

    protected function reject_task($id){
        
        Task::destroy($id);
    }

    
    protected function delete_reason($task_id){
        ReasonForReject::where('task_id',$task_id)->delete();
    }

    protected function update_status($task , $status){
        $task->update(['status' =>$status]);
        return $task;
    }



    protected function hashPass($password){
        return Hash::make($password);
    }
    
    protected function notifyUser($id , $type , $title , $body , $task_id){
        
        $user = User::find($id);
        
        $data = [
            "to" => $user->fcm_token,
            "notification" =>
                [
                'title' => $title,
                'body' => $body,
                'sound' => 'notification.mp3',
                ],
            "data" => [
                "type" => $type,
                'title' => $title,
                'body' => $body,
                'task' => $task_id,
            ],
        ];
        
        return send_notification_FCM($data);
         
    }
    
    protected function uploadFile($file){

        $date = Carbon::now();
        $monthName = $date->format('FY');
        $file_name = time().'.'.$file->extension();
        $full_path = \Storage::path("public/tasks/$monthName/files");
        $file->move($full_path,$file_name);
        return  "tasks/$monthName/files/".$file_name;   
    }
    
    
    protected function deleteOldFile($file){ 
        \Storage::delete('/public/'.$file); 
    }

}