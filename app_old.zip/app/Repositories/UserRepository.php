<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Interfaces\UserRepositoryInterface;
use Illuminate\Support\Facades\Auth;



class UserRepository implements UserRepositoryInterface 
{

    protected $user;

    public function __construct(User $user ){
        $this->user = $user;
    }

    /**
        * This function get all user from model
        *
        * 
        * @return users with transactions
        */

    public function getAllUsers(){

        return User::whereNotIn('id', [1,2])->get();
    }

    public function createUser($data){
        
        $data['password'] = $this->hashPass($data['password']);
        $user =User::create($data);
        $user->assignRole($data['user_type']);

        return $user;

    }


    public function userExist($data){

        if(Auth::attempt($data)){
            return User::where('mobile' , $data['mobile'])->first();
        }
        return false;
        
    }
    
    public function logout(){
        
        return Auth::user()->token()->delete();
    }
    
    
    public function deleteAcc(){
        
        return Auth::user()->delete();
    }

    protected function hashPass($password){
        return Hash::make($password);
    }

    

   

    

}