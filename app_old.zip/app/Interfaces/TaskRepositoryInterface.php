<?php

namespace App\Interfaces;

interface TaskRepositoryInterface 
{
    public function getAllTasks();
    public function createTask($data);
    public function updateTask($data , $id);   
}